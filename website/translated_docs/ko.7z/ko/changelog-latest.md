---
id: changelog-latest
title: Changelog (v1)
---

1.0.7
-----

- QurasDB와의 련동밑에 Transaction의 송수신기능을 추가하였다.

1.0.2
-----

- QurasDB API써버통신모듈을 추가하였습니다.

1.0.1 
-----

- QURAS불록체인 API 리용을 위한 기본 서고들이 개발되였습니다.

  0. Wallet관련 키생성, 변환부분이 추가되였습니다.
  1. QURAS 노드와의 RPC통신모듈기능이 완성되였습니다.